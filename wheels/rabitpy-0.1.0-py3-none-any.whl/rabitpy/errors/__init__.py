

class APINotAvailableError(Exception):
    """
    General Exception when attempting to get data from an API

    """